<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBirthData
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBirthData))
        Me.grpBDate = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtmSec = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtTzSec = New System.Windows.Forms.TextBox()
        Me.lblNote = New System.Windows.Forms.Label()
        Me.txtLat = New System.Windows.Forms.TextBox()
        Me.lblLat = New System.Windows.Forms.Label()
        Me.txtLong = New System.Windows.Forms.TextBox()
        Me.lblLong = New System.Windows.Forms.Label()
        Me.lblhm2 = New System.Windows.Forms.Label()
        Me.txtDstMn = New System.Windows.Forms.TextBox()
        Me.lblDstSep = New System.Windows.Forms.Label()
        Me.txtDstHr = New System.Windows.Forms.TextBox()
        Me.lblWT = New System.Windows.Forms.Label()
        Me.lblhm1 = New System.Windows.Forms.Label()
        Me.txtTzMn = New System.Windows.Forms.TextBox()
        Me.lbltzSep = New System.Windows.Forms.Label()
        Me.txtTzHr = New System.Windows.Forms.TextBox()
        Me.lblhms = New System.Windows.Forms.Label()
        Me.lblddmmyyyy = New System.Windows.Forms.Label()
        Me.lblTZ = New System.Windows.Forms.Label()
        Me.txtPlace = New System.Windows.Forms.TextBox()
        Me.txtMin = New System.Windows.Forms.TextBox()
        Me.txtdd = New System.Windows.Forms.TextBox()
        Me.txtYear = New System.Windows.Forms.TextBox()
        Me.lblTSep2 = New System.Windows.Forms.Label()
        Me.txtSec = New System.Windows.Forms.TextBox()
        Me.txtmm = New System.Windows.Forms.TextBox()
        Me.lblTSep1 = New System.Windows.Forms.Label()
        Me.txtHr = New System.Windows.Forms.TextBox()
        Me.lblDtSep2 = New System.Windows.Forms.Label()
        Me.lblDtSep1 = New System.Windows.Forms.Label()
        Me.lblPlace = New System.Windows.Forms.Label()
        Me.lblTime = New System.Windows.Forms.Label()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.lstPlaceView = New System.Windows.Forms.ListView()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.grpBDate.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpBDate
        '
        Me.grpBDate.Controls.Add(Me.Label3)
        Me.grpBDate.Controls.Add(Me.txtmSec)
        Me.grpBDate.Controls.Add(Me.Label1)
        Me.grpBDate.Controls.Add(Me.txtTzSec)
        Me.grpBDate.Controls.Add(Me.lblNote)
        Me.grpBDate.Controls.Add(Me.txtLat)
        Me.grpBDate.Controls.Add(Me.lblLat)
        Me.grpBDate.Controls.Add(Me.txtLong)
        Me.grpBDate.Controls.Add(Me.lblLong)
        Me.grpBDate.Controls.Add(Me.lblhm2)
        Me.grpBDate.Controls.Add(Me.txtDstMn)
        Me.grpBDate.Controls.Add(Me.lblDstSep)
        Me.grpBDate.Controls.Add(Me.txtDstHr)
        Me.grpBDate.Controls.Add(Me.lblWT)
        Me.grpBDate.Controls.Add(Me.lblhm1)
        Me.grpBDate.Controls.Add(Me.txtTzMn)
        Me.grpBDate.Controls.Add(Me.lbltzSep)
        Me.grpBDate.Controls.Add(Me.txtTzHr)
        Me.grpBDate.Controls.Add(Me.lblhms)
        Me.grpBDate.Controls.Add(Me.lblddmmyyyy)
        Me.grpBDate.Controls.Add(Me.lblTZ)
        Me.grpBDate.Controls.Add(Me.txtPlace)
        Me.grpBDate.Controls.Add(Me.txtMin)
        Me.grpBDate.Controls.Add(Me.txtdd)
        Me.grpBDate.Controls.Add(Me.txtYear)
        Me.grpBDate.Controls.Add(Me.lblTSep2)
        Me.grpBDate.Controls.Add(Me.txtSec)
        Me.grpBDate.Controls.Add(Me.txtmm)
        Me.grpBDate.Controls.Add(Me.lblTSep1)
        Me.grpBDate.Controls.Add(Me.txtHr)
        Me.grpBDate.Controls.Add(Me.lblDtSep2)
        Me.grpBDate.Controls.Add(Me.lblDtSep1)
        Me.grpBDate.Controls.Add(Me.lblPlace)
        Me.grpBDate.Controls.Add(Me.lblTime)
        Me.grpBDate.Controls.Add(Me.lblDate)
        Me.grpBDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpBDate.Location = New System.Drawing.Point(10, 12)
        Me.grpBDate.Name = "grpBDate"
        Me.grpBDate.Size = New System.Drawing.Size(492, 281)
        Me.grpBDate.TabIndex = 0
        Me.grpBDate.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(207, 59)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(10, 15)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = ":"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtmSec
        '
        Me.txtmSec.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtmSec.Location = New System.Drawing.Point(220, 56)
        Me.txtmSec.MaxLength = 3
        Me.txtmSec.Name = "txtmSec"
        Me.txtmSec.Size = New System.Drawing.Size(35, 21)
        Me.txtmSec.TabIndex = 14
        Me.txtmSec.Text = "000"
        Me.txtmSec.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(166, 91)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(10, 15)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = ":"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTzSec
        '
        Me.txtTzSec.BackColor = System.Drawing.SystemColors.Window
        Me.txtTzSec.Enabled = False
        Me.txtTzSec.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTzSec.Location = New System.Drawing.Point(179, 88)
        Me.txtTzSec.MaxLength = 2
        Me.txtTzSec.Name = "txtTzSec"
        Me.txtTzSec.ReadOnly = True
        Me.txtTzSec.Size = New System.Drawing.Size(27, 21)
        Me.txtTzSec.TabIndex = 22
        Me.txtTzSec.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblNote
        '
        Me.lblNote.ForeColor = System.Drawing.Color.Red
        Me.lblNote.Location = New System.Drawing.Point(4, 144)
        Me.lblNote.Name = "lblNote"
        Me.lblNote.Size = New System.Drawing.Size(392, 30)
        Me.lblNote.TabIndex = 29
        Me.lblNote.Text = "Enter few letters of Place and double-click desired one in the popup list"
        Me.lblNote.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtLat
        '
        Me.txtLat.BackColor = System.Drawing.SystemColors.Window
        Me.txtLat.Enabled = False
        Me.txtLat.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLat.Location = New System.Drawing.Point(100, 244)
        Me.txtLat.Name = "txtLat"
        Me.txtLat.ReadOnly = True
        Me.txtLat.Size = New System.Drawing.Size(97, 21)
        Me.txtLat.TabIndex = 35
        Me.txtLat.TabStop = False
        '
        'lblLat
        '
        Me.lblLat.AutoSize = True
        Me.lblLat.Location = New System.Drawing.Point(41, 247)
        Me.lblLat.Name = "lblLat"
        Me.lblLat.Size = New System.Drawing.Size(57, 15)
        Me.lblLat.TabIndex = 34
        Me.lblLat.Text = "Latitude :"
        Me.lblLat.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtLong
        '
        Me.txtLong.BackColor = System.Drawing.SystemColors.Window
        Me.txtLong.Enabled = False
        Me.txtLong.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLong.Location = New System.Drawing.Point(100, 209)
        Me.txtLong.Name = "txtLong"
        Me.txtLong.ReadOnly = True
        Me.txtLong.Size = New System.Drawing.Size(97, 21)
        Me.txtLong.TabIndex = 33
        Me.txtLong.TabStop = False
        '
        'lblLong
        '
        Me.lblLong.AutoSize = True
        Me.lblLong.Location = New System.Drawing.Point(30, 212)
        Me.lblLong.Name = "lblLong"
        Me.lblLong.Size = New System.Drawing.Size(68, 15)
        Me.lblLong.TabIndex = 32
        Me.lblLong.Text = "Longitude :"
        Me.lblLong.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblhm2
        '
        Me.lblhm2.AutoSize = True
        Me.lblhm2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblhm2.Location = New System.Drawing.Point(256, 123)
        Me.lblhm2.Name = "lblhm2"
        Me.lblhm2.Size = New System.Drawing.Size(64, 15)
        Me.lblhm2.TabIndex = 28
        Me.lblhm2.Text = "(Hrs : Min)"
        '
        'txtDstMn
        '
        Me.txtDstMn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDstMn.Location = New System.Drawing.Point(139, 120)
        Me.txtDstMn.MaxLength = 2
        Me.txtDstMn.Name = "txtDstMn"
        Me.txtDstMn.Size = New System.Drawing.Size(27, 21)
        Me.txtDstMn.TabIndex = 27
        Me.txtDstMn.Text = "00"
        Me.txtDstMn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblDstSep
        '
        Me.lblDstSep.AutoSize = True
        Me.lblDstSep.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDstSep.Location = New System.Drawing.Point(128, 123)
        Me.lblDstSep.Name = "lblDstSep"
        Me.lblDstSep.Size = New System.Drawing.Size(10, 15)
        Me.lblDstSep.TabIndex = 26
        Me.lblDstSep.Text = ":"
        Me.lblDstSep.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtDstHr
        '
        Me.txtDstHr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDstHr.Location = New System.Drawing.Point(100, 120)
        Me.txtDstHr.MaxLength = 2
        Me.txtDstHr.Name = "txtDstHr"
        Me.txtDstHr.Size = New System.Drawing.Size(27, 21)
        Me.txtDstHr.TabIndex = 25
        Me.txtDstHr.Text = "00"
        Me.txtDstHr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtDstHr.WordWrap = False
        '
        'lblWT
        '
        Me.lblWT.AutoSize = True
        Me.lblWT.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWT.Location = New System.Drawing.Point(5, 123)
        Me.lblWT.Name = "lblWT"
        Me.lblWT.Size = New System.Drawing.Size(93, 15)
        Me.lblWT.TabIndex = 24
        Me.lblWT.Text = "War Time/DST :"
        Me.lblWT.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblhm1
        '
        Me.lblhm1.AutoSize = True
        Me.lblhm1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblhm1.Location = New System.Drawing.Point(256, 91)
        Me.lblhm1.Name = "lblhm1"
        Me.lblhm1.Size = New System.Drawing.Size(94, 15)
        Me.lblhm1.TabIndex = 23
        Me.lblhm1.Text = "(Hrs : Min : Sec)"
        '
        'txtTzMn
        '
        Me.txtTzMn.BackColor = System.Drawing.SystemColors.Window
        Me.txtTzMn.Enabled = False
        Me.txtTzMn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTzMn.Location = New System.Drawing.Point(139, 88)
        Me.txtTzMn.MaxLength = 2
        Me.txtTzMn.Name = "txtTzMn"
        Me.txtTzMn.ReadOnly = True
        Me.txtTzMn.Size = New System.Drawing.Size(27, 21)
        Me.txtTzMn.TabIndex = 20
        Me.txtTzMn.TabStop = False
        Me.txtTzMn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbltzSep
        '
        Me.lbltzSep.AutoSize = True
        Me.lbltzSep.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltzSep.Location = New System.Drawing.Point(128, 91)
        Me.lbltzSep.Name = "lbltzSep"
        Me.lbltzSep.Size = New System.Drawing.Size(10, 15)
        Me.lbltzSep.TabIndex = 19
        Me.lbltzSep.Text = ":"
        Me.lbltzSep.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtTzHr
        '
        Me.txtTzHr.BackColor = System.Drawing.SystemColors.Window
        Me.txtTzHr.Enabled = False
        Me.txtTzHr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTzHr.Location = New System.Drawing.Point(100, 88)
        Me.txtTzHr.MaxLength = 2
        Me.txtTzHr.Name = "txtTzHr"
        Me.txtTzHr.ReadOnly = True
        Me.txtTzHr.Size = New System.Drawing.Size(27, 21)
        Me.txtTzHr.TabIndex = 18
        Me.txtTzHr.TabStop = False
        Me.txtTzHr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblhms
        '
        Me.lblhms.AutoSize = True
        Me.lblhms.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblhms.Location = New System.Drawing.Point(256, 59)
        Me.lblhms.Name = "lblhms"
        Me.lblhms.Size = New System.Drawing.Size(144, 15)
        Me.lblhms.TabIndex = 15
        Me.lblhms.Text = "(Hrs : Min : Sec: Mili Sec)"
        '
        'lblddmmyyyy
        '
        Me.lblddmmyyyy.AutoSize = True
        Me.lblddmmyyyy.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblddmmyyyy.Location = New System.Drawing.Point(256, 27)
        Me.lblddmmyyyy.Name = "lblddmmyyyy"
        Me.lblddmmyyyy.Size = New System.Drawing.Size(77, 15)
        Me.lblddmmyyyy.TabIndex = 6
        Me.lblddmmyyyy.Text = "(dd/mm/yyyy)"
        '
        'lblTZ
        '
        Me.lblTZ.AutoSize = True
        Me.lblTZ.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTZ.Location = New System.Drawing.Point(26, 91)
        Me.lblTZ.Name = "lblTZ"
        Me.lblTZ.Size = New System.Drawing.Size(72, 15)
        Me.lblTZ.TabIndex = 17
        Me.lblTZ.Text = "Time Zone :"
        Me.lblTZ.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtPlace
        '
        Me.txtPlace.BackColor = System.Drawing.Color.White
        Me.txtPlace.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPlace.Location = New System.Drawing.Point(100, 177)
        Me.txtPlace.Name = "txtPlace"
        Me.txtPlace.Size = New System.Drawing.Size(379, 21)
        Me.txtPlace.TabIndex = 31
        '
        'txtMin
        '
        Me.txtMin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMin.Location = New System.Drawing.Point(138, 56)
        Me.txtMin.MaxLength = 2
        Me.txtMin.Name = "txtMin"
        Me.txtMin.Size = New System.Drawing.Size(27, 21)
        Me.txtMin.TabIndex = 10
        Me.txtMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtdd
        '
        Me.txtdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdd.Location = New System.Drawing.Point(100, 24)
        Me.txtdd.MaxLength = 2
        Me.txtdd.Name = "txtdd"
        Me.txtdd.Size = New System.Drawing.Size(27, 21)
        Me.txtdd.TabIndex = 1
        Me.txtdd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtYear
        '
        Me.txtYear.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtYear.Location = New System.Drawing.Point(179, 24)
        Me.txtYear.MaxLength = 4
        Me.txtYear.Name = "txtYear"
        Me.txtYear.Size = New System.Drawing.Size(46, 21)
        Me.txtYear.TabIndex = 5
        Me.txtYear.Tag = ""
        Me.txtYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblTSep2
        '
        Me.lblTSep2.AutoSize = True
        Me.lblTSep2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTSep2.Location = New System.Drawing.Point(166, 59)
        Me.lblTSep2.Name = "lblTSep2"
        Me.lblTSep2.Size = New System.Drawing.Size(10, 15)
        Me.lblTSep2.TabIndex = 11
        Me.lblTSep2.Text = ":"
        Me.lblTSep2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtSec
        '
        Me.txtSec.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSec.Location = New System.Drawing.Point(179, 56)
        Me.txtSec.MaxLength = 2
        Me.txtSec.Name = "txtSec"
        Me.txtSec.Size = New System.Drawing.Size(27, 21)
        Me.txtSec.TabIndex = 12
        Me.txtSec.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtmm
        '
        Me.txtmm.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtmm.Location = New System.Drawing.Point(138, 24)
        Me.txtmm.MaxLength = 2
        Me.txtmm.Name = "txtmm"
        Me.txtmm.Size = New System.Drawing.Size(27, 21)
        Me.txtmm.TabIndex = 3
        Me.txtmm.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblTSep1
        '
        Me.lblTSep1.AutoSize = True
        Me.lblTSep1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTSep1.Location = New System.Drawing.Point(127, 59)
        Me.lblTSep1.Name = "lblTSep1"
        Me.lblTSep1.Size = New System.Drawing.Size(10, 15)
        Me.lblTSep1.TabIndex = 9
        Me.lblTSep1.Text = ":"
        Me.lblTSep1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtHr
        '
        Me.txtHr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHr.Location = New System.Drawing.Point(100, 56)
        Me.txtHr.MaxLength = 2
        Me.txtHr.Name = "txtHr"
        Me.txtHr.Size = New System.Drawing.Size(27, 21)
        Me.txtHr.TabIndex = 8
        Me.txtHr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblDtSep2
        '
        Me.lblDtSep2.AutoSize = True
        Me.lblDtSep2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDtSep2.Location = New System.Drawing.Point(167, 27)
        Me.lblDtSep2.Name = "lblDtSep2"
        Me.lblDtSep2.Size = New System.Drawing.Size(10, 15)
        Me.lblDtSep2.TabIndex = 4
        Me.lblDtSep2.Text = "/"
        Me.lblDtSep2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblDtSep1
        '
        Me.lblDtSep1.AutoSize = True
        Me.lblDtSep1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDtSep1.Location = New System.Drawing.Point(127, 27)
        Me.lblDtSep1.Name = "lblDtSep1"
        Me.lblDtSep1.Size = New System.Drawing.Size(10, 15)
        Me.lblDtSep1.TabIndex = 2
        Me.lblDtSep1.Text = "/"
        Me.lblDtSep1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblPlace
        '
        Me.lblPlace.AutoSize = True
        Me.lblPlace.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPlace.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblPlace.Location = New System.Drawing.Point(54, 180)
        Me.lblPlace.Name = "lblPlace"
        Me.lblPlace.Size = New System.Drawing.Size(44, 15)
        Me.lblPlace.TabIndex = 30
        Me.lblPlace.Text = "Place :"
        Me.lblPlace.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblTime
        '
        Me.lblTime.AutoSize = True
        Me.lblTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTime.Location = New System.Drawing.Point(57, 59)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(41, 15)
        Me.lblTime.TabIndex = 7
        Me.lblTime.Text = "Time :"
        Me.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblDate
        '
        Me.lblDate.AutoSize = True
        Me.lblDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDate.Location = New System.Drawing.Point(59, 27)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(39, 15)
        Me.lblDate.TabIndex = 0
        Me.lblDate.Text = "Date :"
        Me.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lstPlaceView
        '
        Me.lstPlaceView.FullRowSelect = True
        Me.lstPlaceView.GridLines = True
        Me.lstPlaceView.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None
        Me.lstPlaceView.LabelWrap = False
        Me.lstPlaceView.Location = New System.Drawing.Point(508, 20)
        Me.lstPlaceView.Name = "lstPlaceView"
        Me.lstPlaceView.Size = New System.Drawing.Size(448, 273)
        Me.lstPlaceView.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.lstPlaceView.TabIndex = 5
        Me.lstPlaceView.UseCompatibleStateImageBehavior = False
        Me.lstPlaceView.View = System.Windows.Forms.View.Details
        Me.lstPlaceView.Visible = False
        '
        'btnReset
        '
        Me.btnReset.BackColor = System.Drawing.SystemColors.Control
        Me.btnReset.Location = New System.Drawing.Point(391, 307)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(93, 23)
        Me.btnReset.TabIndex = 9
        Me.btnReset.Text = "Clear Form"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.BackColor = System.Drawing.SystemColors.Control
        Me.btnOK.Location = New System.Drawing.Point(508, 307)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(93, 23)
        Me.btnOK.TabIndex = 10
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'frmBirthData
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.ClientSize = New System.Drawing.Size(963, 335)
        Me.Controls.Add(Me.lstPlaceView)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.grpBDate)
        Me.DoubleBuffered = True
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmBirthData"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "True Astrology Software - Birth Data"
        Me.grpBDate.ResumeLayout(False)
        Me.grpBDate.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents grpBDate As System.Windows.Forms.GroupBox
    Friend WithEvents lblPlace As System.Windows.Forms.Label
    Friend WithEvents lblTime As System.Windows.Forms.Label
    Friend WithEvents lblDate As System.Windows.Forms.Label
    Friend WithEvents txtmm As System.Windows.Forms.TextBox
    Friend WithEvents txtYear As System.Windows.Forms.TextBox
    Friend WithEvents txtdd As System.Windows.Forms.TextBox
    Friend WithEvents lblTSep2 As System.Windows.Forms.Label
    Friend WithEvents txtSec As System.Windows.Forms.TextBox
    Friend WithEvents lblTSep1 As System.Windows.Forms.Label
    Friend WithEvents txtMin As System.Windows.Forms.TextBox
    Friend WithEvents txtHr As System.Windows.Forms.TextBox
    Friend WithEvents lblDtSep2 As System.Windows.Forms.Label
    Friend WithEvents lblDtSep1 As System.Windows.Forms.Label
    Friend WithEvents txtPlace As System.Windows.Forms.TextBox
    Friend WithEvents lblTZ As System.Windows.Forms.Label
    Friend WithEvents lblhms As System.Windows.Forms.Label
    Friend WithEvents lblddmmyyyy As System.Windows.Forms.Label
    Friend WithEvents lblhm1 As System.Windows.Forms.Label
    Friend WithEvents txtTzMn As System.Windows.Forms.TextBox
    Friend WithEvents lbltzSep As System.Windows.Forms.Label
    Friend WithEvents txtTzHr As System.Windows.Forms.TextBox
    Friend WithEvents lblhm2 As System.Windows.Forms.Label
    Friend WithEvents txtDstMn As System.Windows.Forms.TextBox
    Friend WithEvents lblDstSep As System.Windows.Forms.Label
    Friend WithEvents txtDstHr As System.Windows.Forms.TextBox
    Friend WithEvents lblWT As System.Windows.Forms.Label
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents lblLong As System.Windows.Forms.Label
    Friend WithEvents txtLat As System.Windows.Forms.TextBox
    Friend WithEvents lblLat As System.Windows.Forms.Label
    Friend WithEvents txtLong As System.Windows.Forms.TextBox
    Friend WithEvents lblNote As System.Windows.Forms.Label
    Friend WithEvents lstPlaceView As System.Windows.Forms.ListView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtTzSec As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtmSec As System.Windows.Forms.TextBox
End Class
