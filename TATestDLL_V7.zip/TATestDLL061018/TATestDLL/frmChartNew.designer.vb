<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmChartNew
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmChartNew))
        Me.DgDasa = New System.Windows.Forms.DataGridView()
        Me.DgLvH = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.H_SukLC = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.H_PraLC = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PArc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DgLvP = New System.Windows.Forms.DataGridView()
        Me.Planet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.plSgnC = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pDMS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pRL = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.plSTLc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.plSLc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PlSSLc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.H_SukL = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.H_PraL = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pHse = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PDirn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PSt = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lblBhavaH = New System.Windows.Forms.Label()
        Me.PicBoxChart = New System.Windows.Forms.PictureBox()
        Me.lblRashiH = New System.Windows.Forms.Label()
        Me.grpRP = New System.Windows.Forms.GroupBox()
        Me.btnRP = New System.Windows.Forms.Button()
        Me.lblRPTime = New System.Windows.Forms.Label()
        Me.lblRPA = New System.Windows.Forms.Label()
        Me.lblRPAsc = New System.Windows.Forms.Label()
        Me.lblRPM = New System.Windows.Forms.Label()
        Me.lblRPMo = New System.Windows.Forms.Label()
        Me.lblRahu = New System.Windows.Forms.Label()
        Me.lblKetu = New System.Windows.Forms.Label()
        Me.lblDayL = New System.Windows.Forms.Label()
        Me.lblRPRahu = New System.Windows.Forms.Label()
        Me.lblRPKetu = New System.Windows.Forms.Label()
        Me.lblRPDayL = New System.Windows.Forms.Label()
        Me.btnDate = New System.Windows.Forms.Button()
        Me.btnP = New System.Windows.Forms.Button()
        Me.btnS = New System.Windows.Forms.Button()
        Me.btnA = New System.Windows.Forms.Button()
        Me.btnB = New System.Windows.Forms.Button()
        Me.btnDasa = New System.Windows.Forms.Button()
        Me.btnVimD1 = New System.Windows.Forms.Button()
        Me.lblDate1 = New System.Windows.Forms.Label()
        Me.txtVimMon1 = New System.Windows.Forms.TextBox()
        Me.txtVimY1 = New System.Windows.Forms.TextBox()
        Me.lblSep1 = New System.Windows.Forms.Label()
        Me.lblSep2 = New System.Windows.Forms.Label()
        Me.txtVimDay1 = New System.Windows.Forms.TextBox()
        Me.lblVim = New System.Windows.Forms.Label()
        Me.lblVimNote = New System.Windows.Forms.Label()
        Me.btnCurDasa = New System.Windows.Forms.Button()
        Me.lblCuPo = New System.Windows.Forms.Label()
        Me.lblPlPo = New System.Windows.Forms.Label()
        Me.pcSouth = New System.Windows.Forms.PictureBox()
        Me.btnTramsit = New System.Windows.Forms.Button()
        Me.btnDasha = New System.Windows.Forms.Button()
        Me.btnBirthData = New System.Windows.Forms.Button()
        Me.btnTrLoc = New System.Windows.Forms.Button()
        Me.btnDasha3Yr = New System.Windows.Forms.Button()
        CType(Me.DgDasa, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DgLvH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DgLvP, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxChart, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpRP.SuspendLayout()
        CType(Me.pcSouth, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DgDasa
        '
        Me.DgDasa.AllowUserToAddRows = False
        Me.DgDasa.AllowUserToDeleteRows = False
        Me.DgDasa.AllowUserToResizeColumns = False
        Me.DgDasa.AllowUserToResizeRows = False
        Me.DgDasa.BackgroundColor = System.Drawing.SystemColors.Window
        Me.DgDasa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgDasa.ColumnHeadersVisible = False
        Me.DgDasa.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DgDasa.EnableHeadersVisualStyles = False
        Me.DgDasa.Location = New System.Drawing.Point(823, 75)
        Me.DgDasa.MultiSelect = False
        Me.DgDasa.Name = "DgDasa"
        Me.DgDasa.ReadOnly = True
        Me.DgDasa.RowHeadersVisible = False
        Me.DgDasa.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.DgDasa.RowTemplate.DefaultCellStyle.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DgDasa.RowTemplate.Height = 15
        Me.DgDasa.RowTemplate.ReadOnly = True
        Me.DgDasa.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DgDasa.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.DgDasa.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DgDasa.ShowCellToolTips = False
        Me.DgDasa.Size = New System.Drawing.Size(305, 138)
        Me.DgDasa.TabIndex = 386
        '
        'DgLvH
        '
        Me.DgLvH.AllowUserToAddRows = False
        Me.DgLvH.AllowUserToDeleteRows = False
        Me.DgLvH.AllowUserToResizeColumns = False
        Me.DgLvH.AllowUserToResizeRows = False
        Me.DgLvH.BackgroundColor = System.Drawing.Color.White
        Me.DgLvH.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.Pink
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DgLvH.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DgLvH.ColumnHeadersHeight = 18
        Me.DgLvH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DgLvH.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.H_SukLC, Me.H_PraLC, Me.DataGridViewTextBoxColumn8, Me.PArc})
        Me.DgLvH.Enabled = False
        Me.DgLvH.EnableHeadersVisualStyles = False
        Me.DgLvH.Location = New System.Drawing.Point(13, 244)
        Me.DgLvH.MultiSelect = False
        Me.DgLvH.Name = "DgLvH"
        Me.DgLvH.ReadOnly = True
        Me.DgLvH.RowHeadersVisible = False
        Me.DgLvH.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.DgLvH.RowTemplate.DefaultCellStyle.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DgLvH.RowTemplate.Height = 15
        Me.DgLvH.RowTemplate.ReadOnly = True
        Me.DgLvH.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.DgLvH.ShowCellToolTips = False
        Me.DgLvH.Size = New System.Drawing.Size(451, 200)
        Me.DgLvH.TabIndex = 385
        '
        'DataGridViewTextBoxColumn1
        '
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.DataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridViewTextBoxColumn1.HeaderText = "Cusp"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn1.Width = 59
        '
        'DataGridViewTextBoxColumn2
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.DataGridViewTextBoxColumn2.DefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridViewTextBoxColumn2.HeaderText = "Sign"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn2.Width = 37
        '
        'DataGridViewTextBoxColumn3
        '
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewTextBoxColumn3.DefaultCellStyle = DataGridViewCellStyle4
        Me.DataGridViewTextBoxColumn3.HeaderText = "D-M-S"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn3.Width = 61
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.HeaderText = "R L"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        Me.DataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn4.Width = 31
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.HeaderText = "STL"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        Me.DataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn5.Width = 34
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.HeaderText = "SL"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        Me.DataGridViewTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn6.Width = 32
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.HeaderText = "SSL"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        Me.DataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn7.Width = 34
        '
        'H_SukLC
        '
        Me.H_SukLC.HeaderText = "SukL"
        Me.H_SukLC.Name = "H_SukLC"
        Me.H_SukLC.ReadOnly = True
        Me.H_SukLC.Width = 35
        '
        'H_PraLC
        '
        Me.H_PraLC.HeaderText = "PraL"
        Me.H_PraLC.Name = "H_PraLC"
        Me.H_PraLC.ReadOnly = True
        Me.H_PraLC.Width = 34
        '
        'DataGridViewTextBoxColumn8
        '
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewTextBoxColumn8.DefaultCellStyle = DataGridViewCellStyle5
        Me.DataGridViewTextBoxColumn8.HeaderText = "%SArc"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        Me.DataGridViewTextBoxColumn8.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn8.Width = 45
        '
        'PArc
        '
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.PArc.DefaultCellStyle = DataGridViewCellStyle6
        Me.PArc.HeaderText = "%PArc"
        Me.PArc.Name = "PArc"
        Me.PArc.ReadOnly = True
        Me.PArc.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.PArc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.PArc.Width = 45
        '
        'DgLvP
        '
        Me.DgLvP.AllowUserToAddRows = False
        Me.DgLvP.AllowUserToDeleteRows = False
        Me.DgLvP.AllowUserToResizeColumns = False
        Me.DgLvP.AllowUserToResizeRows = False
        Me.DgLvP.BackgroundColor = System.Drawing.Color.White
        Me.DgLvP.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.Pink
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DgLvP.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.DgLvP.ColumnHeadersHeight = 18
        Me.DgLvP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DgLvP.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Planet, Me.plSgnC, Me.pDMS, Me.pRL, Me.plSTLc, Me.plSLc, Me.PlSSLc, Me.H_SukL, Me.H_PraL, Me.pHse, Me.PDirn, Me.PSt})
        Me.DgLvP.Enabled = False
        Me.DgLvP.EnableHeadersVisualStyles = False
        Me.DgLvP.Location = New System.Drawing.Point(13, 23)
        Me.DgLvP.MultiSelect = False
        Me.DgLvP.Name = "DgLvP"
        Me.DgLvP.ReadOnly = True
        Me.DgLvP.RowHeadersVisible = False
        Me.DgLvP.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.DgLvP.RowTemplate.DefaultCellStyle.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DgLvP.RowTemplate.Height = 15
        Me.DgLvP.RowTemplate.ReadOnly = True
        Me.DgLvP.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DgLvP.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.DgLvP.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DgLvP.ShowCellToolTips = False
        Me.DgLvP.Size = New System.Drawing.Size(451, 200)
        Me.DgLvP.TabIndex = 384
        '
        'Planet
        '
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.Planet.DefaultCellStyle = DataGridViewCellStyle8
        Me.Planet.HeaderText = "Planet"
        Me.Planet.Name = "Planet"
        Me.Planet.ReadOnly = True
        Me.Planet.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Planet.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Planet.Width = 56
        '
        'plSgnC
        '
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.plSgnC.DefaultCellStyle = DataGridViewCellStyle9
        Me.plSgnC.HeaderText = "Sign"
        Me.plSgnC.Name = "plSgnC"
        Me.plSgnC.ReadOnly = True
        Me.plSgnC.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.plSgnC.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.plSgnC.Width = 38
        '
        'pDMS
        '
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.pDMS.DefaultCellStyle = DataGridViewCellStyle10
        Me.pDMS.HeaderText = "D-M-S"
        Me.pDMS.Name = "pDMS"
        Me.pDMS.ReadOnly = True
        Me.pDMS.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.pDMS.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.pDMS.Width = 64
        '
        'pRL
        '
        Me.pRL.HeaderText = "R L"
        Me.pRL.Name = "pRL"
        Me.pRL.ReadOnly = True
        Me.pRL.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.pRL.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.pRL.Width = 32
        '
        'plSTLc
        '
        Me.plSTLc.HeaderText = "STL"
        Me.plSTLc.Name = "plSTLc"
        Me.plSTLc.ReadOnly = True
        Me.plSTLc.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.plSTLc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.plSTLc.Width = 32
        '
        'plSLc
        '
        Me.plSLc.HeaderText = "SL"
        Me.plSLc.Name = "plSLc"
        Me.plSLc.ReadOnly = True
        Me.plSLc.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.plSLc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.plSLc.Width = 32
        '
        'PlSSLc
        '
        Me.PlSSLc.HeaderText = "SSL"
        Me.PlSSLc.Name = "PlSSLc"
        Me.PlSSLc.ReadOnly = True
        Me.PlSSLc.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.PlSSLc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.PlSSLc.Width = 32
        '
        'H_SukL
        '
        Me.H_SukL.HeaderText = "SukL"
        Me.H_SukL.Name = "H_SukL"
        Me.H_SukL.ReadOnly = True
        Me.H_SukL.Width = 35
        '
        'H_PraL
        '
        Me.H_PraL.HeaderText = "PraL"
        Me.H_PraL.Name = "H_PraL"
        Me.H_PraL.ReadOnly = True
        Me.H_PraL.Width = 35
        '
        'pHse
        '
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.pHse.DefaultCellStyle = DataGridViewCellStyle11
        Me.pHse.HeaderText = "Hse"
        Me.pHse.Name = "pHse"
        Me.pHse.ReadOnly = True
        Me.pHse.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.pHse.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.pHse.Width = 32
        '
        'PDirn
        '
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.PDirn.DefaultCellStyle = DataGridViewCellStyle12
        Me.PDirn.HeaderText = "D"
        Me.PDirn.Name = "PDirn"
        Me.PDirn.ReadOnly = True
        Me.PDirn.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.PDirn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.PDirn.Width = 28
        '
        'PSt
        '
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.PSt.DefaultCellStyle = DataGridViewCellStyle13
        Me.PSt.HeaderText = "PS"
        Me.PSt.Name = "PSt"
        Me.PSt.ReadOnly = True
        Me.PSt.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.PSt.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.PSt.Width = 32
        '
        'lblBhavaH
        '
        Me.lblBhavaH.BackColor = System.Drawing.Color.Transparent
        Me.lblBhavaH.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.lblBhavaH.ForeColor = System.Drawing.Color.Blue
        Me.lblBhavaH.Location = New System.Drawing.Point(471, 220)
        Me.lblBhavaH.Name = "lblBhavaH"
        Me.lblBhavaH.Size = New System.Drawing.Size(347, 13)
        Me.lblBhavaH.TabIndex = 324
        Me.lblBhavaH.Text = "BHAVA CHART"
        Me.lblBhavaH.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PicBoxChart
        '
        Me.PicBoxChart.BackColor = System.Drawing.Color.Transparent
        Me.PicBoxChart.InitialImage = Nothing
        Me.PicBoxChart.Location = New System.Drawing.Point(470, 25)
        Me.PicBoxChart.Name = "PicBoxChart"
        Me.PicBoxChart.Size = New System.Drawing.Size(349, 414)
        Me.PicBoxChart.TabIndex = 383
        Me.PicBoxChart.TabStop = False
        '
        'lblRashiH
        '
        Me.lblRashiH.BackColor = System.Drawing.Color.Transparent
        Me.lblRashiH.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.lblRashiH.ForeColor = System.Drawing.Color.Blue
        Me.lblRashiH.Location = New System.Drawing.Point(476, 9)
        Me.lblRashiH.Name = "lblRashiH"
        Me.lblRashiH.Size = New System.Drawing.Size(334, 13)
        Me.lblRashiH.TabIndex = 323
        Me.lblRashiH.Text = "RASI CHART"
        Me.lblRashiH.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'grpRP
        '
        Me.grpRP.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.grpRP.BackColor = System.Drawing.Color.Transparent
        Me.grpRP.Controls.Add(Me.btnRP)
        Me.grpRP.Controls.Add(Me.lblRPTime)
        Me.grpRP.Controls.Add(Me.lblRPA)
        Me.grpRP.Controls.Add(Me.lblRPAsc)
        Me.grpRP.Controls.Add(Me.lblRPM)
        Me.grpRP.Controls.Add(Me.lblRPMo)
        Me.grpRP.Controls.Add(Me.lblRahu)
        Me.grpRP.Controls.Add(Me.lblKetu)
        Me.grpRP.Controls.Add(Me.lblDayL)
        Me.grpRP.Controls.Add(Me.lblRPRahu)
        Me.grpRP.Controls.Add(Me.lblRPKetu)
        Me.grpRP.Controls.Add(Me.lblRPDayL)
        Me.grpRP.ForeColor = System.Drawing.Color.Blue
        Me.grpRP.Location = New System.Drawing.Point(18, 456)
        Me.grpRP.Name = "grpRP"
        Me.grpRP.Size = New System.Drawing.Size(312, 184)
        Me.grpRP.TabIndex = 321
        Me.grpRP.TabStop = False
        Me.grpRP.Text = "RULING PLANETS"
        '
        'btnRP
        '
        Me.btnRP.AutoSize = True
        Me.btnRP.BackColor = System.Drawing.Color.AliceBlue
        Me.btnRP.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.btnRP.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnRP.Location = New System.Drawing.Point(133, 144)
        Me.btnRP.Name = "btnRP"
        Me.btnRP.Size = New System.Drawing.Size(68, 27)
        Me.btnRP.TabIndex = 2
        Me.btnRP.Text = "&RP Now !"
        Me.btnRP.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnRP.UseVisualStyleBackColor = True
        '
        'lblRPTime
        '
        Me.lblRPTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblRPTime.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblRPTime.Location = New System.Drawing.Point(8, 20)
        Me.lblRPTime.Name = "lblRPTime"
        Me.lblRPTime.Size = New System.Drawing.Size(220, 31)
        Me.lblRPTime.TabIndex = 1
        Me.lblRPTime.Text = "At  &  Now.Time on 11/11/1111"
        Me.lblRPTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblRPA
        '
        Me.lblRPA.AutoSize = True
        Me.lblRPA.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblRPA.ForeColor = System.Drawing.Color.Blue
        Me.lblRPA.Location = New System.Drawing.Point(34, 55)
        Me.lblRPA.Name = "lblRPA"
        Me.lblRPA.Size = New System.Drawing.Size(41, 15)
        Me.lblRPA.TabIndex = 3
        Me.lblRPA.Text = "ASC :"
        Me.lblRPA.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblRPAsc
        '
        Me.lblRPAsc.AutoSize = True
        Me.lblRPAsc.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.lblRPAsc.ForeColor = System.Drawing.Color.Blue
        Me.lblRPAsc.Location = New System.Drawing.Point(81, 55)
        Me.lblRPAsc.Name = "lblRPAsc"
        Me.lblRPAsc.Size = New System.Drawing.Size(94, 15)
        Me.lblRPAsc.TabIndex = 4
        Me.lblRPAsc.Text = "Su / Ve / Ke / Ra"
        Me.lblRPAsc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblRPM
        '
        Me.lblRPM.AutoSize = True
        Me.lblRPM.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblRPM.ForeColor = System.Drawing.Color.Red
        Me.lblRPM.Location = New System.Drawing.Point(18, 78)
        Me.lblRPM.Name = "lblRPM"
        Me.lblRPM.Size = New System.Drawing.Size(57, 15)
        Me.lblRPM.TabIndex = 5
        Me.lblRPM.Text = "MOON :"
        Me.lblRPM.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblRPMo
        '
        Me.lblRPMo.AutoSize = True
        Me.lblRPMo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.lblRPMo.ForeColor = System.Drawing.Color.Red
        Me.lblRPMo.Location = New System.Drawing.Point(81, 78)
        Me.lblRPMo.Name = "lblRPMo"
        Me.lblRPMo.Size = New System.Drawing.Size(94, 15)
        Me.lblRPMo.TabIndex = 6
        Me.lblRPMo.Text = "Su / Ve / Ke / Ra"
        Me.lblRPMo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblRahu
        '
        Me.lblRahu.AutoSize = True
        Me.lblRahu.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblRahu.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblRahu.Location = New System.Drawing.Point(14, 101)
        Me.lblRahu.Name = "lblRahu"
        Me.lblRahu.Size = New System.Drawing.Size(61, 15)
        Me.lblRahu.TabIndex = 7
        Me.lblRahu.Text = "T.Rahu :"
        Me.lblRahu.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblKetu
        '
        Me.lblKetu.AutoSize = True
        Me.lblKetu.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblKetu.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblKetu.Location = New System.Drawing.Point(19, 124)
        Me.lblKetu.Name = "lblKetu"
        Me.lblKetu.Size = New System.Drawing.Size(56, 15)
        Me.lblKetu.TabIndex = 9
        Me.lblKetu.Text = "T.Ketu :"
        Me.lblKetu.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblDayL
        '
        Me.lblDayL.AutoSize = True
        Me.lblDayL.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.lblDayL.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblDayL.Location = New System.Drawing.Point(3, 152)
        Me.lblDayL.Name = "lblDayL"
        Me.lblDayL.Size = New System.Drawing.Size(72, 15)
        Me.lblDayL.TabIndex = 11
        Me.lblDayL.Text = "Day Lord :"
        Me.lblDayL.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblRPRahu
        '
        Me.lblRPRahu.AutoSize = True
        Me.lblRPRahu.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.lblRPRahu.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblRPRahu.Location = New System.Drawing.Point(81, 101)
        Me.lblRPRahu.Name = "lblRPRahu"
        Me.lblRPRahu.Size = New System.Drawing.Size(44, 15)
        Me.lblRPRahu.TabIndex = 8
        Me.lblRPRahu.Text = "Ju / Sa"
        Me.lblRPRahu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblRPKetu
        '
        Me.lblRPKetu.AutoSize = True
        Me.lblRPKetu.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.lblRPKetu.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblRPKetu.Location = New System.Drawing.Point(81, 124)
        Me.lblRPKetu.Name = "lblRPKetu"
        Me.lblRPKetu.Size = New System.Drawing.Size(44, 15)
        Me.lblRPKetu.TabIndex = 10
        Me.lblRPKetu.Text = "Ju / Sa"
        Me.lblRPKetu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblRPDayL
        '
        Me.lblRPDayL.AutoSize = True
        Me.lblRPDayL.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.lblRPDayL.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblRPDayL.Location = New System.Drawing.Point(81, 152)
        Me.lblRPDayL.Name = "lblRPDayL"
        Me.lblRPDayL.Size = New System.Drawing.Size(23, 15)
        Me.lblRPDayL.TabIndex = 12
        Me.lblRPDayL.Text = "Ju "
        Me.lblRPDayL.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnDate
        '
        Me.btnDate.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnDate.BackColor = System.Drawing.Color.Azure
        Me.btnDate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btnDate.Enabled = False
        Me.btnDate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.btnDate.Location = New System.Drawing.Point(983, 53)
        Me.btnDate.Name = "btnDate"
        Me.btnDate.Size = New System.Drawing.Size(145, 22)
        Me.btnDate.TabIndex = 332
        Me.btnDate.Text = "Ending Date- Time"
        Me.btnDate.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnDate.UseVisualStyleBackColor = False
        '
        'btnP
        '
        Me.btnP.BackColor = System.Drawing.Color.Azure
        Me.btnP.Enabled = False
        Me.btnP.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnP.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.btnP.Location = New System.Drawing.Point(951, 53)
        Me.btnP.Name = "btnP"
        Me.btnP.Size = New System.Drawing.Size(30, 22)
        Me.btnP.TabIndex = 331
        Me.btnP.Text = "P"
        Me.btnP.UseVisualStyleBackColor = False
        '
        'btnS
        '
        Me.btnS.BackColor = System.Drawing.Color.Azure
        Me.btnS.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnS.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.btnS.Location = New System.Drawing.Point(919, 53)
        Me.btnS.Name = "btnS"
        Me.btnS.Size = New System.Drawing.Size(30, 22)
        Me.btnS.TabIndex = 330
        Me.btnS.Text = "S"
        Me.btnS.UseVisualStyleBackColor = False
        '
        'btnA
        '
        Me.btnA.BackColor = System.Drawing.Color.Azure
        Me.btnA.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnA.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.btnA.Location = New System.Drawing.Point(887, 53)
        Me.btnA.Name = "btnA"
        Me.btnA.Size = New System.Drawing.Size(30, 22)
        Me.btnA.TabIndex = 329
        Me.btnA.Text = "A"
        Me.btnA.UseVisualStyleBackColor = False
        '
        'btnB
        '
        Me.btnB.BackColor = System.Drawing.Color.Azure
        Me.btnB.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnB.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.btnB.Location = New System.Drawing.Point(855, 53)
        Me.btnB.Name = "btnB"
        Me.btnB.Size = New System.Drawing.Size(30, 22)
        Me.btnB.TabIndex = 328
        Me.btnB.Text = "B"
        Me.btnB.UseVisualStyleBackColor = False
        '
        'btnDasa
        '
        Me.btnDasa.BackColor = System.Drawing.Color.Azure
        Me.btnDasa.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDasa.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.btnDasa.Location = New System.Drawing.Point(823, 53)
        Me.btnDasa.Name = "btnDasa"
        Me.btnDasa.Size = New System.Drawing.Size(30, 22)
        Me.btnDasa.TabIndex = 327
        Me.btnDasa.Text = "D"
        Me.btnDasa.UseVisualStyleBackColor = False
        '
        'btnVimD1
        '
        Me.btnVimD1.AutoSize = True
        Me.btnVimD1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnVimD1.BackColor = System.Drawing.Color.Azure
        Me.btnVimD1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.btnVimD1.Location = New System.Drawing.Point(1025, 243)
        Me.btnVimD1.Name = "btnVimD1"
        Me.btnVimD1.Size = New System.Drawing.Size(72, 23)
        Me.btnVimD1.TabIndex = 340
        Me.btnVimD1.Text = "Show Dasa"
        Me.btnVimD1.UseVisualStyleBackColor = True
        '
        'lblDate1
        '
        Me.lblDate1.AutoSize = True
        Me.lblDate1.BackColor = System.Drawing.Color.Transparent
        Me.lblDate1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblDate1.Location = New System.Drawing.Point(833, 248)
        Me.lblDate1.Name = "lblDate1"
        Me.lblDate1.Size = New System.Drawing.Size(45, 13)
        Me.lblDate1.TabIndex = 339
        Me.lblDate1.Text = "Date (1)"
        Me.lblDate1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'txtVimMon1
        '
        Me.txtVimMon1.BackColor = System.Drawing.Color.White
        Me.txtVimMon1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.txtVimMon1.Location = New System.Drawing.Point(937, 244)
        Me.txtVimMon1.MaxLength = 2
        Me.txtVimMon1.Name = "txtVimMon1"
        Me.txtVimMon1.Size = New System.Drawing.Size(24, 20)
        Me.txtVimMon1.TabIndex = 335
        Me.txtVimMon1.Text = "00"
        Me.txtVimMon1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtVimY1
        '
        Me.txtVimY1.BackColor = System.Drawing.Color.White
        Me.txtVimY1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.txtVimY1.Location = New System.Drawing.Point(977, 244)
        Me.txtVimY1.MaxLength = 4
        Me.txtVimY1.Name = "txtVimY1"
        Me.txtVimY1.Size = New System.Drawing.Size(40, 20)
        Me.txtVimY1.TabIndex = 338
        Me.txtVimY1.Text = "0000"
        Me.txtVimY1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblSep1
        '
        Me.lblSep1.AutoSize = True
        Me.lblSep1.BackColor = System.Drawing.Color.Transparent
        Me.lblSep1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblSep1.Location = New System.Drawing.Point(961, 248)
        Me.lblSep1.Name = "lblSep1"
        Me.lblSep1.Size = New System.Drawing.Size(13, 13)
        Me.lblSep1.TabIndex = 337
        Me.lblSep1.Text = "--"
        Me.lblSep1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSep2
        '
        Me.lblSep2.AutoSize = True
        Me.lblSep2.BackColor = System.Drawing.Color.Transparent
        Me.lblSep2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblSep2.Location = New System.Drawing.Point(921, 248)
        Me.lblSep2.Name = "lblSep2"
        Me.lblSep2.Size = New System.Drawing.Size(13, 13)
        Me.lblSep2.TabIndex = 336
        Me.lblSep2.Text = "--"
        Me.lblSep2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtVimDay1
        '
        Me.txtVimDay1.BackColor = System.Drawing.Color.White
        Me.txtVimDay1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.txtVimDay1.Location = New System.Drawing.Point(897, 244)
        Me.txtVimDay1.MaxLength = 2
        Me.txtVimDay1.Name = "txtVimDay1"
        Me.txtVimDay1.Size = New System.Drawing.Size(24, 20)
        Me.txtVimDay1.TabIndex = 334
        Me.txtVimDay1.Text = "00"
        Me.txtVimDay1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblVim
        '
        Me.lblVim.BackColor = System.Drawing.Color.Transparent
        Me.lblVim.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lblVim.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblVim.Location = New System.Drawing.Point(820, 5)
        Me.lblVim.Name = "lblVim"
        Me.lblVim.Size = New System.Drawing.Size(296, 16)
        Me.lblVim.TabIndex = 325
        Me.lblVim.Text = "VimSottari Dasa"
        Me.lblVim.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblVimNote
        '
        Me.lblVimNote.BackColor = System.Drawing.Color.Transparent
        Me.lblVimNote.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblVimNote.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblVimNote.Location = New System.Drawing.Point(824, 21)
        Me.lblVimNote.Name = "lblVimNote"
        Me.lblVimNote.Size = New System.Drawing.Size(296, 26)
        Me.lblVimNote.TabIndex = 326
        Me.lblVimNote.Text = "Double Click respective Row to see D-B-A-S-P, To jump back click the respective H" & _
    "eader"
        Me.lblVimNote.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnCurDasa
        '
        Me.btnCurDasa.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnCurDasa.BackColor = System.Drawing.Color.Azure
        Me.btnCurDasa.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.btnCurDasa.Location = New System.Drawing.Point(912, 215)
        Me.btnCurDasa.Name = "btnCurDasa"
        Me.btnCurDasa.Size = New System.Drawing.Size(125, 23)
        Me.btnCurDasa.TabIndex = 333
        Me.btnCurDasa.Text = "Show Current Dasa"
        Me.btnCurDasa.UseVisualStyleBackColor = False
        '
        'lblCuPo
        '
        Me.lblCuPo.BackColor = System.Drawing.Color.Transparent
        Me.lblCuPo.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.75!, System.Drawing.FontStyle.Bold)
        Me.lblCuPo.ForeColor = System.Drawing.Color.Blue
        Me.lblCuPo.Location = New System.Drawing.Point(15, 222)
        Me.lblCuPo.Name = "lblCuPo"
        Me.lblCuPo.Size = New System.Drawing.Size(429, 26)
        Me.lblCuPo.TabIndex = 320
        Me.lblCuPo.Text = "CUSPAL POSITIONS"
        Me.lblCuPo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblPlPo
        '
        Me.lblPlPo.BackColor = System.Drawing.Color.Transparent
        Me.lblPlPo.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.75!, System.Drawing.FontStyle.Bold)
        Me.lblPlPo.ForeColor = System.Drawing.Color.Blue
        Me.lblPlPo.Location = New System.Drawing.Point(15, 5)
        Me.lblPlPo.Name = "lblPlPo"
        Me.lblPlPo.Size = New System.Drawing.Size(429, 16)
        Me.lblPlPo.TabIndex = 319
        Me.lblPlPo.Text = "PLANETARY POSITIONS"
        Me.lblPlPo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pcSouth
        '
        Me.pcSouth.BackColor = System.Drawing.Color.Transparent
        Me.pcSouth.InitialImage = Nothing
        Me.pcSouth.Location = New System.Drawing.Point(825, 271)
        Me.pcSouth.Name = "pcSouth"
        Me.pcSouth.Size = New System.Drawing.Size(349, 414)
        Me.pcSouth.TabIndex = 387
        Me.pcSouth.TabStop = False
        '
        'btnTramsit
        '
        Me.btnTramsit.AutoSize = True
        Me.btnTramsit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTramsit.Location = New System.Drawing.Point(390, 492)
        Me.btnTramsit.Name = "btnTramsit"
        Me.btnTramsit.Size = New System.Drawing.Size(133, 30)
        Me.btnTramsit.TabIndex = 388
        Me.btnTramsit.Text = "Transit Chart"
        Me.btnTramsit.UseVisualStyleBackColor = True
        '
        'btnDasha
        '
        Me.btnDasha.AutoSize = True
        Me.btnDasha.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDasha.Location = New System.Drawing.Point(390, 565)
        Me.btnDasha.Name = "btnDasha"
        Me.btnDasha.Size = New System.Drawing.Size(133, 30)
        Me.btnDasha.TabIndex = 389
        Me.btnDasha.Text = "Full Dasha DBA"
        Me.btnDasha.UseVisualStyleBackColor = True
        '
        'btnBirthData
        '
        Me.btnBirthData.AutoSize = True
        Me.btnBirthData.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBirthData.Location = New System.Drawing.Point(554, 563)
        Me.btnBirthData.Name = "btnBirthData"
        Me.btnBirthData.Size = New System.Drawing.Size(125, 30)
        Me.btnBirthData.TabIndex = 390
        Me.btnBirthData.Text = "Birth Data"
        Me.btnBirthData.UseVisualStyleBackColor = True
        '
        'btnTrLoc
        '
        Me.btnTrLoc.AutoSize = True
        Me.btnTrLoc.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTrLoc.Location = New System.Drawing.Point(554, 492)
        Me.btnTrLoc.Name = "btnTrLoc"
        Me.btnTrLoc.Size = New System.Drawing.Size(125, 30)
        Me.btnTrLoc.TabIndex = 391
        Me.btnTrLoc.Text = "Transit Locator"
        Me.btnTrLoc.UseVisualStyleBackColor = True
        '
        'btnDasha3Yr
        '
        Me.btnDasha3Yr.AutoSize = True
        Me.btnDasha3Yr.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDasha3Yr.Location = New System.Drawing.Point(390, 622)
        Me.btnDasha3Yr.Name = "btnDasha3Yr"
        Me.btnDasha3Yr.Size = New System.Drawing.Size(133, 30)
        Me.btnDasha3Yr.TabIndex = 392
        Me.btnDasha3Yr.Text = "3Yrs Dasha"
        Me.btnDasha3Yr.UseVisualStyleBackColor = True
        '
        'frmChartNew
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(1181, 686)
        Me.Controls.Add(Me.btnDasha3Yr)
        Me.Controls.Add(Me.btnTrLoc)
        Me.Controls.Add(Me.btnBirthData)
        Me.Controls.Add(Me.btnDasha)
        Me.Controls.Add(Me.btnTramsit)
        Me.Controls.Add(Me.lblBhavaH)
        Me.Controls.Add(Me.pcSouth)
        Me.Controls.Add(Me.DgDasa)
        Me.Controls.Add(Me.DgLvH)
        Me.Controls.Add(Me.DgLvP)
        Me.Controls.Add(Me.lblRashiH)
        Me.Controls.Add(Me.grpRP)
        Me.Controls.Add(Me.btnDate)
        Me.Controls.Add(Me.btnP)
        Me.Controls.Add(Me.btnS)
        Me.Controls.Add(Me.btnA)
        Me.Controls.Add(Me.btnB)
        Me.Controls.Add(Me.btnDasa)
        Me.Controls.Add(Me.btnVimD1)
        Me.Controls.Add(Me.lblDate1)
        Me.Controls.Add(Me.txtVimMon1)
        Me.Controls.Add(Me.txtVimY1)
        Me.Controls.Add(Me.lblSep1)
        Me.Controls.Add(Me.lblSep2)
        Me.Controls.Add(Me.txtVimDay1)
        Me.Controls.Add(Me.lblVim)
        Me.Controls.Add(Me.lblVimNote)
        Me.Controls.Add(Me.btnCurDasa)
        Me.Controls.Add(Me.lblCuPo)
        Me.Controls.Add(Me.lblPlPo)
        Me.Controls.Add(Me.PicBoxChart)
        Me.DoubleBuffered = True
        Me.ForeColor = System.Drawing.Color.Black
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmChartNew"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "Chart Display"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.DgDasa, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DgLvH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DgLvP, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxChart, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpRP.ResumeLayout(False)
        Me.grpRP.PerformLayout()
        CType(Me.pcSouth, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DgDasa As System.Windows.Forms.DataGridView
    Friend WithEvents DgLvH As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents H_SukLC As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents H_PraLC As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PArc As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DgLvP As System.Windows.Forms.DataGridView
    Friend WithEvents Planet As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents plSgnC As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents pDMS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents pRL As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents plSTLc As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents plSLc As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PlSSLc As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents H_SukL As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents H_PraL As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents pHse As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PDirn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PSt As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents lblBhavaH As System.Windows.Forms.Label
    Friend WithEvents PicBoxChart As System.Windows.Forms.PictureBox
    Friend WithEvents lblRashiH As System.Windows.Forms.Label
    Friend WithEvents grpRP As System.Windows.Forms.GroupBox
    Friend WithEvents btnRP As System.Windows.Forms.Button
    Friend WithEvents lblRPTime As System.Windows.Forms.Label
    Friend WithEvents lblRPA As System.Windows.Forms.Label
    Friend WithEvents lblRPAsc As System.Windows.Forms.Label
    Friend WithEvents lblRPM As System.Windows.Forms.Label
    Friend WithEvents lblRPMo As System.Windows.Forms.Label
    Friend WithEvents lblRahu As System.Windows.Forms.Label
    Friend WithEvents lblKetu As System.Windows.Forms.Label
    Friend WithEvents lblDayL As System.Windows.Forms.Label
    Friend WithEvents lblRPRahu As System.Windows.Forms.Label
    Friend WithEvents lblRPKetu As System.Windows.Forms.Label
    Friend WithEvents lblRPDayL As System.Windows.Forms.Label
    Friend WithEvents btnDate As System.Windows.Forms.Button
    Friend WithEvents btnP As System.Windows.Forms.Button
    Friend WithEvents btnS As System.Windows.Forms.Button
    Friend WithEvents btnA As System.Windows.Forms.Button
    Friend WithEvents btnB As System.Windows.Forms.Button
    Friend WithEvents btnDasa As System.Windows.Forms.Button
    Friend WithEvents btnVimD1 As System.Windows.Forms.Button
    Friend WithEvents lblDate1 As System.Windows.Forms.Label
    Friend WithEvents txtVimMon1 As System.Windows.Forms.TextBox
    Friend WithEvents txtVimY1 As System.Windows.Forms.TextBox
    Friend WithEvents lblSep1 As System.Windows.Forms.Label
    Friend WithEvents lblSep2 As System.Windows.Forms.Label
    Friend WithEvents txtVimDay1 As System.Windows.Forms.TextBox
    Friend WithEvents lblVim As System.Windows.Forms.Label
    Friend WithEvents lblVimNote As System.Windows.Forms.Label
    Friend WithEvents btnCurDasa As System.Windows.Forms.Button
    Friend WithEvents lblCuPo As System.Windows.Forms.Label
    Friend WithEvents lblPlPo As System.Windows.Forms.Label
    Friend WithEvents pcSouth As System.Windows.Forms.PictureBox
    Friend WithEvents btnTramsit As System.Windows.Forms.Button
    Friend WithEvents btnDasha As System.Windows.Forms.Button
    Friend WithEvents btnBirthData As System.Windows.Forms.Button
    Friend WithEvents btnTrLoc As System.Windows.Forms.Button
    Friend WithEvents btnDasha3Yr As System.Windows.Forms.Button
End Class
